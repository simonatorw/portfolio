# Dashboard

## Development

1) node server.jsx (runs mocked server)
2) npm i
3) npm start

## Testing

### Unit and Integration Tests

* npm test
_or_
* npm run test:coverage (runs tests and  summary)

### End-to-end Tests

#### TestCafe

1) Start development environment (Above)
2) npm run test:e2e

#### Cypress (Nicer)

1) Start development environment (Above)
2) install-cypress (runs batch file to install software if not installed already)
3) npm run cypress:open

## Production

1) npm i
2) npm run build