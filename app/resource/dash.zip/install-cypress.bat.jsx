SET CYPRESS_BINARY_VERSION=cypress/install/cypress.zip
npm i cypress