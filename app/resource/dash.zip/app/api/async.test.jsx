import { fetchGet, setSSE } from './async';

describe('Test fetchGet function', () => {
    test('It will return a formatted date', async () => {
		const result = await fetchGet({ foo: 'bar' });
		const expected = 'bar';
        expect(result.foo).toEqual(expected);
    });	
});

describe('Test setSSE function', () => {
	const msg = ['foo', 'bar'];
	let msgSource;
	
	beforeAll(() => {
		msgSource = setSSE(msg);
	});

    test('It will return obj after init', async () => {
		const result = msgSource;
		const expected = expect.any(Object);
		
        expect(result).toEqual(expected);
    });
	
    test('It will return 1st SSE msg', async () => {
		const result = await msgSource.nextMessage();
		const expected = msg[0];
		
        expect(result).toEqual(expected);
    });

    test('It will return 2nd SSE msg', async () => {
		const result = await msgSource.nextMessage();
		const expected = msg[1];
		
        expect(result).toEqual(expected);
    });
	
	describe('It will return a promise when resolving', () => {
		const msg = ['foo', 'bar'];
		let msgSource;
		
		beforeAll(() => {
			msgSource = setSSE(msg);
		});
	
		test('It will not resolve until nextMessage is called again', async () => {
			const msgSource = setSSE(msg);
			
			await msgSource.nextMessage();
			
			const result = msgSource.nextMessage()
			const expected = expect.any(Object);
			
			expect(result).toEqual(expected);
		});
		
		test('It will not create a new promise until previous one is resolved', () => {
			msgSource.nextMessage();
			
			const result = msgSource.nextMessage();		
			const expected = expect.any(Object);		
			
			expect(result).toEqual(expected);
		});
	})
});