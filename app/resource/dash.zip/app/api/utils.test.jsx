import { configure } from 'enzyme';
import Adapter from 'enzyme-adapter-react-15';

import { getStoreKey, saveThemeToStorage, retreiveTheme } from './utils';

configure({ adapter: new Adapter() });

describe('Test getStoreKey function', () => {
    test('It will generate the correct store key', () => {
        const input = 'FOO_BAR_DATA';
		const expected = 'fooBar';
		
        expect(getStoreKey(input)).toEqual(expected);
    });

    test('It will generate a store key w/only one delimiter', () => {
        const input = 'FOO_DATA';
		const expected = 'foo';
		
        expect(getStoreKey(input)).toEqual(expected);
    });	
});

describe('Test theme save/retrieve', () => {
	let theme;
	
	beforeAll(() => {
			theme = 'Bloomie';
			
			saveThemeToStorage(theme);
	});

	describe('Test saveThemeToStorage function', () => {
		test('It will save the theme to local storage', () => {
			const result = localStorage.getItem('dashboard_theme');
			const expected = theme;
			
			expect(result).toEqual(expected);
		});
	});

	describe('Test retreiveTheme function', () => {
		test('It will retreive the theme from local storage', () => {
			const result = retreiveTheme();
			const expected = theme;
			
			expect(result).toEqual(expected);
		});
		
		test('It will use Simple theme if there is nothing in local storage', () => {
			localStorage.clear();
			
			const result = retreiveTheme();
			const expected = 'Simple';
			
			expect(result).toEqual(expected);
		});		
	});	
});