import { theming } from '../constants';
import themes from '../components/ThemePicker/themes';

export function getStoreKey(key) {
	const parts = key.toLowerCase().substring(0, key.indexOf('_DATA')).split('_');
	
	return  parts[0] + parts.map((key, i) => i ? key.charAt(0).toUpperCase()  + key.substring(1) : '').join('');
}

export function saveThemeToStorage(theme) {
	localStorage.setItem(theming.STORAGE_KEY, theme);
}

export const retreiveTheme = () => localStorage.getItem(theming.STORAGE_KEY) ? localStorage.getItem(theming.STORAGE_KEY) : Object.keys(themes)[0];
