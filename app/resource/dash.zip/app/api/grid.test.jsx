import React from 'react';
import { configure, shallow } from 'enzyme';
import Adapter from 'enzyme-adapter-react-15';

import LineChart from '../components/charts/LineChart/LineChart';
import BarChart from '../components/charts/BarChart/BarChart';
import { isGridNumber, getChart, formatGridData, getGridClass } from './grid';
import { gridClasses, ticker } from '../constants';

configure({ adapter: new Adapter() });

describe('Test isGridNumber function', () => {
    test('It will recognize currency in millions', () => {
		const data = '$16233M';
		const result = isGridNumber(data);
		const expected = true;
		
		expect(result).toEqual(expected);
    });
	
    test('It will recognize negative currency in millions', () => {
		const data = '-$16233M';
		const result = isGridNumber(data);
		const expected = true;
		
		expect(result).toEqual(expected);
    });	

    test('It will recognize percentage', () => {
		const data = '26%';
		const result = isGridNumber(data);
		const expected = true;
		
		expect(result).toEqual(expected);
    });

    test('It will recognize negative percentage', () => {
		const data = '-26%';
		const result = isGridNumber(data);
		const expected = true;
		
		expect(result).toEqual(expected);
    });

    test('It will recognize integers', () => {
		const data = 26;
		const result = isGridNumber(data);
		const expected = true;
		
		expect(result).toEqual(expected);
    });

    test('It will recognize negative integers', () => {
		const data = -26;
		const result = isGridNumber(data);
		const expected = true;
		
		expect(result).toEqual(expected);
    });

    test('It will recognize decimals', () => {
		const data = 2.6;
		const result = isGridNumber(data);
		const expected = true;
		
		expect(result).toEqual(expected);
    });

    test('It will recognize negative decimals', () => {
		const data = -2.6;
		const result = isGridNumber(data);
		const expected = true;
		
		expect(result).toEqual(expected);
    });	
});

describe('Test getChart function', () => {
	const data = {};
	
    test('It will return placeholder if it is not a line or bar chart', () => {
        const chartType = 'foo';
		const result = getChart(chartType, data);
		const expected = '<chart>';
		
        expect(result).toEqual(expected);
    });	
	
    test('It will return a line chart if chartType is line', () => {
        const chartType = 'line';
		const result = shallow(getChart(chartType, data));
		const expected = shallow(
			<LineChart data={data} />
		);
		
        expect(result.name()).toEqual(expected.name());
    });
	
    test('It will return a bar chart if chartType is bar', () => {
        const chartType = 'bar';
		const result = shallow(getChart(chartType, data));
		const expected = shallow(
			<BarChart data={data} />
		);
		
        expect(result.name()).toEqual(expected.name());
    });	
});

describe('Test formatGridData function', () => {
    test('It will return a number', () => {
		const data = 18;
		const result = formatGridData(data);
		const expected = 18;
		
		expect(result).toEqual(expected);
    });
	
    test('It will return a string', () => {
		const data = 'foo';
		const result = formatGridData(data);
		const expected = 'foo';
		
		expect(result).toEqual(expected);
    });

    test('It will return a chart', () => {		
		const data = { chartType: 'line', data: {} };
		const result = shallow(formatGridData(data));
		const expected = shallow(
			<LineChart data={data} />
		);
		
		expect(result.name).toEqual(expected.name);
    });

    test('It will return a link', () => {		
		const data = { text: 'foo', url: 'http://bar' };
		const result = shallow(formatGridData(data));
		const expected = shallow(
			<a href="http://bar" target="_tab" className="link">foo</a>
		);
		
		expect(result).toEqual(expected);
    });
	
    test('It will return a value within an object', () => {		
		const data = { value: 'foo' };
		const result = formatGridData(data);
		const expected = 'foo';
		
		expect(result).toEqual(expected);
    });	

    test('It will return null string if there is no data', () => {
		const result = formatGridData();
		const expected = '';
		
		expect(result).toEqual(expected);
    });	
});

describe('Test getGridClass function', () => {
    test('It will return a chart style class', () => {
		const data = { chartType: 'line' };
		const result = getGridClass(data);
		const expected = ` ${gridClasses.CHART}`;
		
		expect(result).toEqual(expected);
    });
	
    test('It will return a link style class for hyperlink', () => {
		const data = {};
		const result = getGridClass(data);
		const expected = ` ${gridClasses.LINK}`;
		
		expect(result).toEqual(expected);
    });

    test('It will return a link style class for modal link', () => {
		const data = 'foo';
		const props = {
			clickHandler: {}
		}
		const indx = 0;
		const result = getGridClass(data, null, props, indx);
		const expected = ` ${gridClasses.LINK}`;
		
		expect(result).toEqual(expected);
    });

    test('It will return a number style class', () => {
		const data = 10;
		const result = getGridClass(data);
		const expected = ` ${gridClasses.AMT}`;
		
		expect(result).toEqual(expected);
    });

    test('It will return a negative number style class', () => {
		const data = -10;
		const result = getGridClass(data);
		const expected = ` ${gridClasses.NEG_AMT}`;
		
		expect(result).toEqual(expected);
    });

    test('It will return a negative number style class for percentage', () => {
		const data = '-10%';
		const result = getGridClass(data);
		const expected = ` ${gridClasses.NEG_AMT}`;
		
		expect(result).toEqual(expected);
    });

    test('It will return a number style class for numbers inside an object', () => {
		const data = { value: '-10%' };
		const result = getGridClass(data);
		const expected = ` ${gridClasses.NEG_AMT}`;
		
		expect(result).toEqual(expected);
    });

    test('It will return an empty style class for null strings', () => {
		const data = '';
		const result = getGridClass(data);
		const expected = ` ${gridClasses.EMPTY}`;
		
		expect(result).toEqual(expected);
    });
	
    test('It will return a sibling uptick style class for real time data', () => {
		const data = { value: 10, tick: ticker.UP };
		const animSwitch = true;
		const result = getGridClass(data, animSwitch);
		const expected = ` amt ${gridClasses.UP}`;
		
		expect(result).toEqual(expected);
    });

    test('It will return a different sibling uptick style class for real time data when animation switch is toggled', () => {
		const data = { value: 10, tick: ticker.UP };
		const animSwitch = false;
		const result = getGridClass(data, animSwitch);
		const expected = ` amt ${gridClasses.UP0}`;
		
		expect(result).toEqual(expected);
    });

    test('It will return a sibling downtick style class for real time data', () => {
		const data = { value: 10, tick: ticker.DOWN };
		const animSwitch = true;
		const result = getGridClass(data, animSwitch);
		const expected = ` amt ${gridClasses.DOWN}`;
		
		expect(result).toEqual(expected);
    });

    test('It will return a different sibling downtick style class for real time data when animation switch is toggled', () => {
		const data = { value: 10, tick: ticker.DOWN };
		const animSwitch = false;
		const result = getGridClass(data, animSwitch);
		const expected = ` amt ${gridClasses.DOWN0}`;
		
		expect(result).toEqual(expected);
    });	
});