import Chartist from 'chartist';
import 'chartist-plugin-legend';

import './chartist-plugin-axistitle';
import { getShortMonthDay } from './date';
import { chartClasses } from '../constants';

export function setBarOptions(data) {
	const options = {
		height: '28px',
		showGridBackground: false,
		chartPadding: {
			top: 0,
			right: 0,
			bottom: 0,
			left: 0
		},
		axisX: {
			offset: 0,
			showLabel: false,
			showGrid: false
		},
		axisY: {
			offset: 0,
			showLabel: false,
			showGrid: false
		}
	};
	let chartClass;
	
	if (data.params) {
		if (data.params.horizontalBars) {
			options.horizontalBars = data.params.horizontalBars;
			options.reverseData = true;
			chartClass = chartClasses.BAR_HORIZONTAL;
		}
		if (data.params.stackBars) {
			options.stackBars = data.params.stackBars;
			if (data.params.low && data.params.high) {
				data.series.length && data.series[0][0] > 0 ? chartClass = chartClasses.STACK_BAR_UP : chartClass = chartClasses.STACK_BAR_DOWN;
			}
		}
		if (data.params.low) {
			options.axisX.low = data.params.low;
		}
		if (data.params.high) {
			options.axisX.high = data.params.high;
		}
	}
	
	return { options, chartClass };
}

export function setLineOptions(data) {
	let options = {
		height: '28px',
		showGridBackground: false,
		showPoint: false,
		fullWidth: true,
		chartPadding: {
			top: 2,
			right: 0,
			bottom: 2,
			left: 0
		},
		axisX: {
			offset: 0,
			showLabel: false,
			showGrid: false
		},
		axisY: {
			offset: 0,
			showLabel: false,
			showGrid: false
		}
	};
	
	if (data.params && data.params.detailed) {
		options = {
			height: '230px',
			showGridBackground: false,
			showPoint: false,
			fullWidth: true,
			low: 0,
			high: 200,
			chartPadding: {
				top: 0,
				right: 0,
				bottom: 18,
				left: 10
			},			
			axisX: {
				showGrid: true,
				position: 'end',
				labelInterpolationFnc: function(label, cnt) {
					if (typeof label === 'string' && label.includes('-')) {
						if (!(cnt % 2)) {
							cnt++;
							return getShortMonthDay(label);
						} else {
							cnt++;
							return '';
						}
					}
					return label;
				}
			},
			axisY: {
				showGrid: true,
				position: 'start'
			},
			plugins: [
				Chartist.plugins.legend(),
				Chartist.plugins.ctAxisTitle({
					axisX: {
						axisTitle: data.params.xTitle || ' ',
						axisClass: 'ct-axis-title',
						offset: {
							x: 0,
							y: 45
						},
						textAnchor: 'middle'
					},
					axisY: {
						axisTitle: data.params.yTitle || ' ',
						axisClass: 'ct-axis-title',
						offset: {
							x: 0,
							y: 12
						},
						textAnchor: 'middle',
						flipTitle: true
					}
				})
			]
		};
	}
	
	return options;
}