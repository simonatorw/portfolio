import { setBarOptions, setLineOptions } from './chart';
import { chartClasses } from '../constants';

describe('Test setBarOptions function', () => {
	let result;
	
	describe('Test default bar chart options', () => {
		beforeAll(() => {
			const input = {};
			result = setBarOptions(input);
		});
		
		test('It will return an object', () => {
			const expected = expect.any(Object);

			expect(result).toEqual(expected);
		});
		
		test('It will return an object with 2 keys', () => { 
			const expected = 2;

			expect(Object.keys(result).length).toEqual(expected);
		});

		test('It will return a horiztonal bar chart config', () => { 
			const expected = undefined;

			expect(result.chartClass).toEqual(expected);
		});
	});	
	
	describe('Test horizontal bar chart options', () => {
		beforeAll(() => {
			const input = { params: { horizontalBars: true }};
			result = setBarOptions(input);
		});
		
		test('It will return an object', () => {
			const expected = expect.any(Object);

			expect(result).toEqual(expected);
		});
		
		test('It will return an object with 2 keys', () => { 
			const expected = 2;

			expect(Object.keys(result).length).toEqual(expected);
		});

		test('It will return a horiztonal bar chart config', () => { 
			const expected = chartClasses.BAR_HORIZONTAL;

			expect(result.chartClass).toEqual(expected);
		});
	});
	
	describe('Test stack bar chart options', () => {
		test('It will return an up stack bar chart config', () => { 
			const input = { params: { stackBars: true, low: true, high: true }, series: [[1]] };
			const result = setBarOptions(input);
			const expected = chartClasses.STACK_BAR_UP;

			expect(result.chartClass).toEqual(expected);
		});
		
		test('It will return a down stack bar chart config', () => { 
			const input = { params: { stackBars: true, low: true, high: true }, series: [[-1]] };
			const result = setBarOptions(input);
			const expected = chartClasses.STACK_BAR_DOWN;

			expect(result.chartClass).toEqual(expected);
		});

		test('It will return a stack bar chart with no defined class without low or high params', () => { 
			const input = { params: { stackBars: true }, series: [[-1]] };
			const result = setBarOptions(input);
			const expected = undefined;

			expect(result.chartClass).toEqual(expected);
		});		
	});	
});

describe('Test setLineOptions function', () => {
	let result;
	
	describe('Test simple line chart options', () => {
		beforeAll(() => {
			const input = {};
			result = setLineOptions(input);
		});

		test('It will return an object', () => {
			const expected = expect.any(Object);
			
			expect(result).toEqual(expected);
		});
		
		test('It will return a simple line chart config', () => {
			const expected = '28px';
			
			expect(result.height).toEqual(expected);
		});		
	});
	
	describe('Test detailed line chart options', () => {
		beforeAll(() => {
			const input = { params: { detailed: true }};
			result = setLineOptions(input);
		});
		
		test('It will return a detailed line chart config', () => {
			const expected = '230px';
			
			expect(result.height).toEqual(expected);
		});

		test('It will return a detailed line chart config w/plugins', () => {
			const expected = expect.any(Array);
			
			expect(result.plugins).toEqual(expected);
		});

		test('It will return a detailed line chart config w/labels for even values', () => {
			const expected = 'Jan 27';
			const labelFunc = result.axisX.labelInterpolationFnc('2017-01-27', 0);
			
			expect(labelFunc).toEqual(expected);
		});

		test('It will return a detailed line chart config w/labels but not for odd values', () => {
			const expected = '';
			const labelFunc = result.axisX.labelInterpolationFnc('2017-01-27', 1);
			
			expect(labelFunc).toEqual(expected);
		});

		test('It will return a detailed line chart config w/labels unchanged for non-strings and non-dashed dataes/values', () => {
			const expected = 100;
			const labelFunc = result.axisX.labelInterpolationFnc(100, 1);
			
			expect(labelFunc).toEqual(expected);
		});		
	});	
});
