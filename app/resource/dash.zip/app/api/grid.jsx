import React from 'react';

import { chartTypes } from '../constants';
import BarChart from '../components/charts/BarChart/BarChart';
import LineChart from '../components/charts/LineChart/LineChart';
import { nativeTypes, gridClasses, ticker } from '../constants';

export function isGridNumber(data) {
	return (typeof data === nativeTypes.NUMBER || !isNaN(parseFloat(data)) || data.indexOf('$') === 0 || data.indexOf('$') === 1);
}

export function getChart(chartType, data) {
	switch(chartType) {
		case chartTypes.LINE:
			return (
				<LineChart data={data} />
			);
		case chartTypes.BAR:
			return (
				<BarChart data={data} />
			);
		default:
			return '<chart>';
	}
}

export function formatGridData(data) {
	if (typeof data === nativeTypes.OBJECT) {
		if (data.chartType) {
			return getChart(data.chartType, data.data);
		} else if (data.url) {
			return (<a href={data.url} target="_tab" className="link">{data.text}</a>);
		} else {
			return data.value;
		}
	} else if (data || typeof data === nativeTypes.NUMBER) {
		return data;
	} else {
		return '';
	}
}

export function getGridClass(data, animSwitch, props, indx) {
	let styleClasses = '';
	let dataItem = data;
	
	if (data.value) {
		dataItem = data.value;
	}
	
	if (typeof dataItem === nativeTypes.OBJECT) {
		if (dataItem.chartType) {
			styleClasses = `${styleClasses} ${gridClasses.CHART}`;
		} else {
			styleClasses = `${styleClasses} ${gridClasses.LINK}`;	
		}
	} else if (props && props.clickHandler && indx === 0) {
		styleClasses = `${styleClasses} ${gridClasses.LINK}`;
	} else if (isGridNumber(dataItem)) {
		if (typeof dataItem === nativeTypes.STRING && dataItem.includes('-') || (typeof dataItem === nativeTypes.NUMBER && dataItem < 0)) {
			styleClasses = `${styleClasses} ${gridClasses.NEG_AMT}`;
		} else {
			styleClasses = `${styleClasses} ${gridClasses.AMT}`;
		}
	} else if (dataItem === '') {
		styleClasses = `${styleClasses} ${gridClasses.EMPTY}`;
	}
	
	if (data.value || data.text) {
		if (data.tick === ticker.UP) {
			if (animSwitch) {
				styleClasses = `${styleClasses} ${gridClasses.UP}`;
			} else {
				styleClasses = `${styleClasses} ${gridClasses.UP0}`;
			}
		} else if (data.tick === ticker.DOWN) {
			if (animSwitch) {
				styleClasses = `${styleClasses} ${gridClasses.DOWN}`;
			} else {
				styleClasses = `${styleClasses} ${gridClasses.DOWN0}`;
			}			
		}
	}
	
	return styleClasses;
}