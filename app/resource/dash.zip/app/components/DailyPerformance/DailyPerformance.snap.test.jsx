import React from 'react';
import { configure, shallow } from 'enzyme';
import toJson from 'enzyme-to-json';
import Adapter from 'enzyme-adapter-react-15';

import { DailyPerformanceTpl } from './DailyPerformance';
import { mapStateToProps } from './DailyPerformance';

configure({ adapter: new Adapter() });

describe('Test DailyPerformance component', () => {
	test('It will match the DailyPerformance snapshot', () => {
		const data = {};
		const result = shallow(<DailyPerformanceTpl data={data} />);

		expect(toJson(result)).toMatchSnapshot();	
	});

	test('It will test mapStateToProps for DailyPerformance', () => {
		const store = {
			dataReducer: {
				dailyPerformance: 'foo'
			}
		};
		const result = mapStateToProps(store);
		const expected = 'foo';

		expect(result.data).toEqual(expected);	
	});
});	