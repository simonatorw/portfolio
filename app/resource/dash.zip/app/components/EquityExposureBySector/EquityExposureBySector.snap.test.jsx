import React from 'react';
import { configure, shallow } from 'enzyme';
import toJson from 'enzyme-to-json';
import Adapter from 'enzyme-adapter-react-15';

import { EquityExposureBySectorTpl } from './EquityExposureBySector';
import { mapStateToProps } from './EquityExposureBySector';

configure({ adapter: new Adapter() });

describe('Test EquityBeta component', () => {
	test('It will match the EquityBeta snapshot', () => {
		const data = {};
		const result = shallow(<EquityExposureBySectorTpl data={data} />);

		expect(toJson(result)).toMatchSnapshot();	
	});

	test('It will test mapStateToProps for EquityExposureBySector', () => {
		const store = {
			dataReducer: {
				equityExposureBySector: 'foo'
			}
		};
		const result = mapStateToProps(store);
		const expected = 'foo';

		expect(result.data).toEqual(expected);	
	});
});