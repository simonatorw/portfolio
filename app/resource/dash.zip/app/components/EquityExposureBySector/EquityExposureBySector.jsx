import React from 'react';
import { connect } from 'react-redux';
import { object } from 'prop-types';

import DataGrid from '../DataGrid/DataGrid';

export function EquityExposureBySectorTpl({ data }) {
    return (
        <div className="panel gridBig">
            <h2>Equity Exposure By Sector</h2>
            <DataGrid data={data} />
        </div>
    );
}

EquityExposureBySectorTpl.propTypes = {
	data: object
};

export function mapStateToProps(store) {
	return {
		data: store.dataReducer.equityExposureBySector
	};
}

export default connect(mapStateToProps)(EquityExposureBySectorTpl);