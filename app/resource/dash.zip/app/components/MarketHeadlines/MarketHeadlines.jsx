import React from 'react';
import { connect } from 'react-redux';
import { object } from 'prop-types';

import DataGrid from '../DataGrid/DataGrid';

import './MarketHeadlines.css';

export function MarketHeadlinesTpl({ data }) {
    return (
        <div className="panel" id="marketHeadlines">
            <h2>Market Headlines</h2>
            <DataGrid data={data} />
        </div>
    );
}

MarketHeadlinesTpl.propTypes = {
	data: object.isRequired
};

export function mapStateToProps(store) {
	return {
		data: store.dataReducer.marketHeadlines
	};
}

export default connect(mapStateToProps)(MarketHeadlinesTpl);