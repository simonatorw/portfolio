import React from 'react';
import { configure, shallow } from 'enzyme';
import toJson from 'enzyme-to-json';
import Adapter from 'enzyme-adapter-react-15';

import { MarketHeadlinesTpl } from './MarketHeadlines';
import { mapStateToProps } from './MarketHeadlines';

configure({ adapter: new Adapter() });

describe('Test MarketHeadlines component', () => {
	test('It will match the MarketHeadlines snapshot', () => {
		const data = {};
		const result = shallow(<MarketHeadlinesTpl data={data} />);

		expect(toJson(result)).toMatchSnapshot();	
	});

	test('It will test mapStateToProps for MarketHeadlines', () => {
		const store = {
			dataReducer: {
				marketHeadlines: 'foo'
			}
		};
		const result = mapStateToProps(store);
		const expected = 'foo';

		expect(result.data).toEqual(expected);	
	});
});	