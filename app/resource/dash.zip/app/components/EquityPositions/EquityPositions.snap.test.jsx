import React from 'react';
import { configure, shallow } from 'enzyme';
import toJson from 'enzyme-to-json';
import Adapter from 'enzyme-adapter-react-15';

import { EquityPositionsTpl } from './EquityPositions';
import { mapStateToProps, mapDispatchToProps } from './EquityPositions';
import { gridClasses } from '../../constants';

configure({ adapter: new Adapter() });

describe('Test EquityPositions component', () => {
	test('It will match the EquityPositions snapshot', () => {
		const data = {};
		const result = shallow(<EquityPositionsTpl data={data} />);

		expect(toJson(result)).toMatchSnapshot();	
	});

	test('It will test mapStateToProps for EquityPositions', () => {
		const store = {
			dataReducer: {
				equityPositions: 'foo'
			}
		};
		const result = mapStateToProps(store);
		const expected = 'foo';

		expect(result.data).toEqual(expected);	
	});
	
	describe('Test mapDispatchToProps for EquityPositions', () => {
		const dispatch = jest.fn();	
		const dispatchObj = mapDispatchToProps(dispatch);
		
		test('It will return an object from mapDispatchToProps', () => {
			const expected = expect.any(Object);

			expect(dispatchObj).toEqual(expected);	
		});

		test('It will test dispatch an action for delegateEvent method', () => {
			const delegateEventFn = dispatchObj.delegateEvent;	
			const event = {
				target: {
					className: gridClasses.LINK,
					textContent: 'Foo Bar'
				}
			};
			const result = delegateEventFn(event);
			const expected = 'FooBar';

			expect(result).toEqual(expected);	
		});
		
		test('It will test not dispatch an action for delegateEvent method if it does not have a link style class', () => {
			const delegateEventFn = dispatchObj.delegateEvent;	
			const event = {
				target: {
					className: 'foo'
				}
			};
			const result = delegateEventFn(event);
			const expected = undefined;

			expect(result).toEqual(expected);	
		});
		
	});
});