import React from 'react';
import { connect } from 'react-redux';
import { object } from 'prop-types';

import DataGrid from '../DataGrid/DataGrid';
import { nativeTypes, gridClasses } from '../../constants';
import { modalGet } from '../../store/actions/actionCreators';

export function EquityPositionsTpl({ data, delegateEvent }) {
    return (
        <div className="panel long">
            <h2>Equity Positions</h2>
            <DataGrid data={data} clickHandler={delegateEvent} />
        </div>
    );
}

EquityPositionsTpl.propTypes = {
	data: object.isRequired
};

export function mapStateToProps(store) {
	return {
		data: store.dataReducer.equityPositions
	};
}

export function mapDispatchToProps(dispatch, ownProps) {
	return {
		delegateEvent: function(e) {
			const cls = e.target.className;
			
			if (typeof cls === nativeTypes.STRING && cls.includes(gridClasses.LINK)) {
				const serviceName = e.target.textContent.replace(/\s+/g, '');
				
				dispatch(modalGet('EquityPositionsDetail', serviceName));
				return serviceName;
			}
		}
	}
}

export default connect(mapStateToProps, mapDispatchToProps)(EquityPositionsTpl);