import React from 'react';
import { connect } from 'react-redux';
import { object } from 'prop-types';

import DataGrid from '../DataGrid/DataGrid';

export function EquityBetaTpl({ data }) {
    return (
        <div className="panel">
            <h2>Equity Beta</h2>
            <DataGrid data={data} />
        </div>
    );
}

EquityBetaTpl.propTypes = {
	data: object.isRequired
};

export function mapStateToProps(store) {
	return {
		data: store.dataReducer.equityBeta
	};
}

export default connect(mapStateToProps)(EquityBetaTpl);