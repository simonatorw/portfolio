import React from 'react';
import { configure, shallow } from 'enzyme';
import toJson from 'enzyme-to-json';
import Adapter from 'enzyme-adapter-react-15';

import { EquityBetaTpl } from './EquityBeta';
import { mapStateToProps } from './EquityBeta';

configure({ adapter: new Adapter() });

describe('Test EquityBeta component', () => {
	test('It will match the EquityBeta snapshot', () => {
		const data = {};
		const result = shallow(<EquityBetaTpl data={data} />);

		expect(toJson(result)).toMatchSnapshot();	
	});

	test('It will test mapStateToProps for EquityBeta', () => {
		const store = {
			dataReducer: {
				equityBeta: 'foo'
			}
		};
		const result = mapStateToProps(store);
		const expected = 'foo';

		expect(result.data).toEqual(expected);	
	});
});