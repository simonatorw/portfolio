import React from 'react';
import { connect } from 'react-redux';
import { object, func } from 'prop-types';

import { modalClose } from '../../store/actions/actionCreators';
import EquityPositionsDetail from '../EquityPositionsDetail/EquityPositionsDetail';

import './Modal.css';

const components = {
	EquityPositionsDetail
};

export function ModalTpl({ data, closeModal }) {
	const VarComp = components[data.comp];

    return (
		<div>
			{ data.title && 
			<div>
				<div className="modal">
					<VarComp data={data} closeHandler={closeModal} />
				</div>
				<div className="screen" onClick={closeModal}></div>
			</div>
			}
		</div>
    );
}

ModalTpl.propTypes = {
	data: object.isRequired,
	closeModal: func.isRequired
};

export function mapStateToProps(store) {
	return {
		data: store.appReducer.modal
	};
}

export function mapDispatchToProps(dispatch, ownProps) {
	return {
		closeModal: function(e) {			
			dispatch(modalClose());
		}
	}
}

export default connect(mapStateToProps, mapDispatchToProps)(ModalTpl);
