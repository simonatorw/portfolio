import React from 'react';
import { configure, shallow } from 'enzyme';
import toJson from 'enzyme-to-json';
import Adapter from 'enzyme-adapter-react-15';

import { ModalTpl } from './Modal';
import { mapStateToProps, mapDispatchToProps } from './Modal';

configure({ adapter: new Adapter() });

describe('Test Modal component', () => {
	test('It will match the Modal snapshot', () => {
		const data = {
			title: 'foo',
			comp: 'EquityPositionsDetail'
		};
		const closeModal = jest.fn();
		const result = shallow(<ModalTpl data={data} closeModal={closeModal} />);

		expect(toJson(result)).toMatchSnapshot();	
	});

	test('It will test mapStateToProps for Modal', () => {
		const store = {
			appReducer: {
				modal: 'foo'
			}
		};
		const result = mapStateToProps(store);
		const expected = 'foo';

		expect(result.data).toEqual(expected);	
	});
	
	describe('Test mapDispatchToProps for Modal', () => {
		const dispatch = jest.fn();	
		const dispatchObj = mapDispatchToProps(dispatch);
		
		test('It will return an object from mapDispatchToProps', () => {
			const expected = expect.any(Object);

			expect(dispatchObj).toEqual(expected);	
		});

		test('It will dispatch action when closeModal is called', () => {
			dispatchObj.closeModal();
			const expected = 1;

			expect(dispatch.mock.calls.length).toBe(expected);	
		});		
	});	
});	