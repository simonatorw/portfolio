import React from 'react';
import { configure, shallow } from 'enzyme';
import toJson from 'enzyme-to-json';
import Adapter from 'enzyme-adapter-react-15';

jest.mock('../../app/api/date');
import { getTodaysDate } from '../../app/api/date';
import App, { AppTpl } from './App';

configure({ adapter: new Adapter() });

getTodaysDate.mockReturnValue('December 21, 2017');

describe('Test App component', () => {
	test('It will match the App container snapshot', () => {
		const result = shallow(<App />);

		expect(toJson(result)).toMatchSnapshot();	
	});
	
	test('It will match the App template snapshot', () => {
		const result = shallow(<AppTpl />);

		expect(toJson(result)).toMatchSnapshot();	
	});	
});