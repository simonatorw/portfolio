import React from 'react';
import renderer from 'react-test-renderer';

import CloseIcon from './CloseIcon';

describe('Test CloseIcon component', () => {
	test('It will match the CloseIcon snapshot', () => {
		const func = jest.fn();
		const rendered = renderer.create(<CloseIcon clickHandler={func} />);

		expect(rendered.toJSON()).toMatchSnapshot();	
	});
});