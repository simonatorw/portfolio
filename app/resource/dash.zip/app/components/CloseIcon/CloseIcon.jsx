import React from 'react';
import { func } from 'prop-types';

import './CloseIcon.css';

export default function CloseIconTpl({ clickHandler }) {
    return (
		<div className="closeIcon" onClick={clickHandler}></div>
    );
}

CloseIconTpl.propTypes = {
	clickHandler: func.isRequired
};