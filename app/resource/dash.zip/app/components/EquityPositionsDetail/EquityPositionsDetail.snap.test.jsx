import React from 'react';
import { configure, shallow } from 'enzyme';
import toJson from 'enzyme-to-json';
import Adapter from 'enzyme-adapter-react-15';

import EquityPositionsDetailTpl from './EquityPositionsDetail';

configure({ adapter: new Adapter() });

describe('Test EquityPositionsDetail component', () => {
	test('It will match the EquityPositionsDetail snapshot', () => {
		const data = {
			content: [
				{ subTitle: 'foo', grid: {} },
				{ subTitle: 'bar', grid: {} }
			]
		};
		const closeHandler = jest.fn();
		const result = shallow(<EquityPositionsDetailTpl data={data} closeHandler={closeHandler} />);

		expect(toJson(result)).toMatchSnapshot();	
	});
});