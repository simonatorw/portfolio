import React from 'react';
import { object, func } from 'prop-types';

import KeyMetrics from '../KeyMetrics/KeyMetrics';
import CloseIcon from '../CloseIcon/CloseIcon';
import DataGrid from '../DataGrid/DataGrid';

import './EquityPositionsDetail.css';

export default function EquityPositionsDetailTpl({ data, closeHandler }) {
    return (
		<div id="equityPositionsDetail">
			<div className="container">
				<header className="panel header">
					<h2>{data.title}</h2><CloseIcon clickHandler={closeHandler} />
				</header>
				{ data.content.map((panel, i) => 
				<div className="panel" key={panel.subTitle}>
					<h3>{panel.subTitle}</h3>
					<DataGrid data={panel.grid} />
				</div>
				)}
			</div>
		</div>
    );
}

EquityPositionsDetailTpl.propTypes = {
	data: object.isRequired,
	closeHandler: func.isRequired
};