import React from 'react';
import { configure, shallow } from 'enzyme';
import toJson from 'enzyme-to-json';
import Adapter from 'enzyme-adapter-react-15';

import { EquityPositionsCountTpl } from './EquityPositionsCount';
import { mapStateToProps } from './EquityPositionsCount';

configure({ adapter: new Adapter() });

describe('Test EquityPositionsCount component', () => {
	test('It will match the EquityPositionsCount snapshot', () => {
		const data = {
			data: [
				{ data: {} }
			]
		};
		const result = shallow(<EquityPositionsCountTpl data={data} />);

		expect(toJson(result)).toMatchSnapshot();	
	});

	test('It will test mapStateToProps for EquityPositionsCount', () => {
		const store = {
			dataReducer: {
				equityPositionsCount: 'foo'
			}
		};
		const result = mapStateToProps(store);
		const expected = 'foo';

		expect(result.data).toEqual(expected);	
	});
});