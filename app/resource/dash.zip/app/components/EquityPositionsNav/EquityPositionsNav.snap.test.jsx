import React from 'react';
import { configure, shallow } from 'enzyme';
import toJson from 'enzyme-to-json';
import Adapter from 'enzyme-adapter-react-15';

import { EquityPositionsNavTpl } from './EquityPositionsNav';
import { mapStateToProps } from './EquityPositionsNav';

configure({ adapter: new Adapter() });

describe('Test EquityPositionsNav component', () => {
	test('It will match the EquityPositionsNav snapshot', () => {
		const data = {
			data: [
				{ data: {} }
			]
		};
		const result = shallow(<EquityPositionsNavTpl data={data} />);

		expect(toJson(result)).toMatchSnapshot();	
	});

	test('It will test mapStateToProps for EquityPositionsNav', () => {
		const store = {
			dataReducer: {
				equityPositionsNav: 'foo'
			}
		};
		const result = mapStateToProps(store);
		const expected = 'foo';

		expect(result.data).toEqual(expected);	
	});
});