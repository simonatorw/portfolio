import React, { Component } from 'react';

import { formatGridData, getGridClass } from '../../api/grid';

import './DataGrid.css';

export default class DataGrid extends Component {
	animSwitch = true;

    render() {
		this.animSwitch = this.animSwitch ? false : true;

        return (
            <table className="dataGrid" onClick={this.props.clickHandler}>
                <thead>
                    <tr>
                    { this.props.data.headers.map((headerName, i) => 
                        <th className="gridHead" key={`header_${i}`}>{headerName}</th>
                    )}
                    </tr>
                </thead>
                <tbody>
                { this.props.data.data.map((row, i) => 
                    <tr key={`row_${i}`} className="gridRow">
                    { Object.keys(row).map((key, i) =>
                        <td className={ `gridCell${getGridClass(row[key], this.animSwitch, this.props, i)}` } key={`col_${i}`}>
                            { formatGridData(row[key]) }
                        </td>
                    )}
                    </tr>
                )}
                </tbody>
            </table>
        );
    }
}