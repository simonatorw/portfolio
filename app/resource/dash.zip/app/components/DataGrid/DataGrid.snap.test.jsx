import React from 'react';
import { configure, shallow } from 'enzyme';
import toJson from 'enzyme-to-json';
import Adapter from 'enzyme-adapter-react-15';

import DataGrid from './DataGrid';

configure({ adapter: new Adapter() });

describe('Test DataGrid component', () => {
	let rendered;
	
	beforeAll( () => {
		const data = {
			headers: [
				'foo', 'bar'
			],
			data: [
				{ foo: 'foo', bar: 'bar' },
				{ foo: 'foo2', bar: 'bar2' }
			]
		};
		
		rendered = shallow(
			<DataGrid data={data} />
		);
	});	
	
	test('It will match the DataGrid snapshot', () => {
		const result = toJson(rendered);
		
		expect(result).toMatchSnapshot();	
	});
	
	test('It will initially have animation flag set to false', () => {
		const result = rendered.instance().animSwitch;
		const expected = false;
		
		expect(result).toEqual(expected);	
	});

	test('It will have animation flag set to true on re-render', () => {
		rendered.instance().forceUpdate();
		
		const result = rendered.instance().animSwitch;
		const expected = true;
		
		expect(result).toEqual(expected);	
	});	
});	