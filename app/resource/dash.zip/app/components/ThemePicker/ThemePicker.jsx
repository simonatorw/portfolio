import React from 'react';
import { connect } from 'react-redux';
import { string, func } from 'prop-types';

import themes from './themes';
import { changeTheme } from '../../store/actions/actionCreators';

import './ThemePicker.css';

export function ThemePickerTpl({ selectTheme, theme }) {
	const keys = Object.keys(themes);
	
	return (
		<div className="themePicker">
			<label className="themeLabel">Theme</label>
			<select className="themeSelect" onChange={selectTheme} defaultValue={theme}>
				{ keys.map(themeOption => (<option key={themeOption}>{themeOption}</option>)) }
			</select>
			<div>
				<style>
					{ themes[theme] }
				</style>
			</div>
		</div>
	);
}

ThemePickerTpl.propTypes = {
	theme: string.isRequired,
	selectTheme: func.isRequired
};

export function mapStateToProps(store) {
	return {
		theme: store.appReducer.theme
	};
}

export function mapDispatchToProps(dispatch, ownProps) {
	return {
		selectTheme: function(e) {
			const theme = e.target.value;
			
			dispatch(changeTheme(theme));
			return theme;
		}
	}
}

export default connect(mapStateToProps, mapDispatchToProps)(ThemePickerTpl);