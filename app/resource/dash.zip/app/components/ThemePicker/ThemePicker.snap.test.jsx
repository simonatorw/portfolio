import React from 'react';
import { configure, shallow } from 'enzyme';
import toJson from 'enzyme-to-json';
import Adapter from 'enzyme-adapter-react-15';

import { ThemePickerTpl } from './ThemePicker';
import { mapStateToProps, mapDispatchToProps } from './ThemePicker';

configure({ adapter: new Adapter() });

describe('Test ThemePicker component', () => {
	test('It will match the Modal snapshot', () => {
		const theme = 'foo';
		const selectTheme = jest.fn();
		const result = shallow(<ThemePickerTpl theme={theme} selectTheme={selectTheme} />);

		expect(toJson(result)).toMatchSnapshot();	
	});

	test('It will test mapStateToProps for ThemePicker', () => {
		const store = {
			appReducer: {
				theme: 'foo'
			}
		};
		const result = mapStateToProps(store);
		const expected = 'foo';

		expect(result.theme).toEqual(expected);	
	});
	
	describe('Test mapDispatchToProps for ThemePicker', () => {
		const dispatch = jest.fn();	
		const dispatchObj = mapDispatchToProps(dispatch);
		const evt = {
			target: {
				value: 'foo'
			}
		};
		const dispatchResult = dispatchObj.selectTheme(evt);
		
		test('It will return an object from mapDispatchToProps', () => {
			const expected = expect.any(Object);

			expect(dispatchObj).toEqual(expected);	
		});

		test('It will dispatch action when closeModal is called', () => {
			const expected = 1;

			expect(dispatch.mock.calls.length).toBe(expected);	
		});

		test('It will dispatch action with correct theme when closeModal is called', () => {
			const expected = 'foo';

			expect(dispatchResult).toEqual(expected);	
		});		
	});
});	