export default {
	Simple: ``,
	Bloomie: `body {
		background-color: #000;
		color: orange;
	}
	.dataGrid .gridCell.link, .dataGrid .gridCell .link,
	.dataGrid .gridCell.link:visited, .dataGrid .gridCell .link:visited	{
		color: orange;
	}
	body #app, #equityPositionsDetail {
		background-color: #333;
	}
	.container h1, .container .panel h2, .container .panel h3, .dataGrid .gridHead {
		color: #fff;
	}
	.container .panel {
		background-color: #000;
	}
	.ct-label {
		color: rgba(255, 255, 255, .6);
	}
	.ct-grid {
		stroke: rgba(255, 255, 255, .6);
	}
	.ct-series-a .ct-bar {
		stroke: #0781c5;
	}
	.stackBarChartDown .ct-series-a .ct-bar, .stackBarChartUp .ct-series-a .ct-bar {
		stroke: #666;
	}	
	.container .panel.gridBig tbody .gridRow:nth-child(even) .ct-bar {
		stroke: #1ab4e9;
	}`,
	FinTimes: `body {
		background-color: #fff1e0;
		color: #333;
	}
	.dataGrid .gridCell.link, .dataGrid .gridCell .link,
	.dataGrid .gridCell.link:visited, .dataGrid .gridCell .link:visited	{
		color: #333;
	}
	body #app, #equityPositionsDetail {
		background-color: #e9decf;
	}
	.container .panel {
		background-color: #fff1e0;
	}
	.container h1, .container .panel h2, .container .panel h3 {
		font-family: times;
	}
	.stackBarChartDown .ct-series-a .ct-bar, .stackBarChartUp .ct-series-a .ct-bar {
		stroke: #ddd;
	}`,	
	Mono: `body {
		background-color: #666;
		color: #306;
		font-family: verdana, sans-serif;
	}
	body #app, #equityPositionsDetail {
		background-color: #dedede;
	}
	.dataGrid .gridCell.link, .dataGrid .gridCell .link,
	.dataGrid .gridCell.link:visited, .dataGrid .gridCell .link:visited	{
		color: #306;
	}
	.container .panel {
		background-color: #eee;
	}
	.ct-label {
		color: #c9c;
	}
	.ct-series-a .ct-bar, .barChart .ct-series-a .ct-bar {
		stroke: #306;
	}
	.stackBarChartDown .ct-series-a .ct-bar, .stackBarChartUp .ct-series-a .ct-bar {
		stroke: #ccc;
	}
	.barChart .ct-series-b .ct-bar, .container .panel.gridBig tbody .gridRow:nth-child(even) .ct-bar, .ct-grid {
		stroke: #c9c;
	}
	.ct-axis-title {
		fill: #306;
	}`
};