import React, { Component } from 'react';

import { getTodaysDate } from '../api/date.jsx';
import { getStoreKey } from '../api/utils';
import { dataGet, dataSubscribe } from '../store/actions/actionCreators';
import { dataUrls, subscribeUrls, subscribeCols } from '../constants';
import store from '../store/store';
import KeyMetrics from './KeyMetrics/KeyMetrics';
import DailyPerformance from './DailyPerformance/DailyPerformance';
import EquityBeta from './EquityBeta/EquityBeta';
import MarketHeadlines from './MarketHeadlines/MarketHeadlines';
import EquityPositions from './EquityPositions/EquityPositions';
import EquityExposureBySector from './EquityExposureBySector/EquityExposureBySector';
import EquityPositionsCount from './EquityPositionsCount/EquityPositionsCount';
import EquityPositionsNav from './EquityPositionsNav/EquityPositionsNav';
import ThemePicker from './ThemePicker/ThemePicker';
import Modal from './Modal/Modal';

import './App.css';

export function AppTpl() {
	return (
		<div className="container">
			<header className="panel header">
				<h1>Daily Metrics | Portfolio Manager - Equity | {getTodaysDate()}</h1><ThemePicker />
			</header>
			<section className="subContainer">
				<section className="subContainer2">
					<KeyMetrics />
					<DailyPerformance />
					<EquityBeta />
				</section>
				<MarketHeadlines />
				<EquityExposureBySector />
				<EquityPositionsCount />
				<EquityPositionsNav />
			</section>
			<EquityPositions />
			<Modal />
		</div>
	);
}

export default class App extends Component {
	componentWillMount() {
		const urlKeys = Object.keys(dataUrls);
		const subscribeKeys = Object.keys(subscribeUrls);

		urlKeys.forEach(key => { store.dispatch(dataGet(dataUrls[key], getStoreKey(key))) });
		subscribeKeys.forEach(key => { store.dispatch(dataSubscribe(subscribeUrls[key], getStoreKey(key), subscribeCols[key])) });
	}
	
	render() {
		return (
			<AppTpl />
		);
	}
}