import React from 'react';
import { connect } from 'react-redux';
import { object } from 'prop-types';

import DataGrid from '../DataGrid/DataGrid';

export function KeyMetricsTpl({ data }) {
    return (
        <div className="panel">
            <h2>Key Metrics</h2>
            <DataGrid data={data} />
        </div>
    );
}

KeyMetricsTpl.propTypes = {
	data: object.isRequired
};

export function mapStateToProps(store) {
	return {
		data: store.dataReducer.keyMetrics
	};
}

export default connect(mapStateToProps)(KeyMetricsTpl);