import React from 'react';
import { configure, shallow } from 'enzyme';
import toJson from 'enzyme-to-json';
import Adapter from 'enzyme-adapter-react-15';

import { KeyMetricsTpl } from './KeyMetrics';
import { mapStateToProps } from './KeyMetrics';

configure({ adapter: new Adapter() });

describe('Test KeyMetrics component', () => {
	test('It will match the KeyMetrics snapshot', () => {
		const data = {};
		const result = shallow(<KeyMetricsTpl data={data} />);

		expect(toJson(result)).toMatchSnapshot();	
	});

	test('It will test mapStateToProps for KeyMetrics', () => {
		const store = {
			dataReducer: {
				keyMetrics: 'foo'
			}
		};
		const result = mapStateToProps(store);
		const expected = 'foo';

		expect(result.data).toEqual(expected);	
	});
});	