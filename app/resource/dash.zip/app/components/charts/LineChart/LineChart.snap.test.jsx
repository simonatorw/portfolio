import React from 'react';
import renderer from 'react-test-renderer';

import LineChart from './LineChart';

describe('Test LineChart component', () => {
	test('It will match the LineChart snapshot', () => {
		const data = {};
		const rendered = renderer.create(<LineChart data={data} />);

		expect(rendered.toJSON()).toMatchSnapshot();	
	});
});