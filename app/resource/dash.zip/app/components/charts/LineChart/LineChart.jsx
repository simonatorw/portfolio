import React, { Component } from 'react';
import { object } from 'prop-types';
import Chartist from 'chartist';

import { setLineOptions } from '../../../api/chart';

import '../charts.css';

export default class LineChart extends Component {
	static propTypes = {
		data: object.isRequired
	};
	componentDidMount() {
		new Chartist.Line(this.el, {
			labels: this.props.data.labels,
			series: this.props.data.series
		}, setLineOptions(this.props.data));		
	}
	render() {
		return (
			<div>
				<div className="lineChart" ref={el => this.el = el}></div>
			</div>
		);
	}
}
