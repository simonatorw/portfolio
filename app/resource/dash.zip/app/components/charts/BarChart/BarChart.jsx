import React, { Component } from 'react';
import { object } from 'prop-types';
import Chartist from 'chartist';

import { chartClasses } from '../../../constants';
import { setBarOptions } from '../../../api/chart';

export default class BarChart extends Component {
	static propTypes = {
		data: object.isRequired
	};
	state = {
		chartClass: chartClasses.BAR
	};
	componentDidMount() {
		const { options, chartClass } = setBarOptions(this.props.data);
		
		if (chartClass) {
			this.setState({ chartClass });
		}
		new Chartist.Bar(this.el, {
			labels: this.props.data.labels,
			series: this.props.data.series
			
		}, options);		
	}
	render() {
		return (
			<div>
				<div className={this.state.chartClass} ref={el => this.el = el}></div>
			</div>
		);
	}
}
