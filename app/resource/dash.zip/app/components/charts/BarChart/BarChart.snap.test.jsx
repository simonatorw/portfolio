import React from 'react';
import renderer from 'react-test-renderer';
import Adapter from 'enzyme-adapter-react-15';
import { configure, mount } from 'enzyme';

import BarChart from './BarChart';
import { chartClasses } from '../../../constants';

configure({ adapter: new Adapter() });

describe('Test BarChart component', () => {
	test('It will match the BarChart snapshot', () => {
		const data = {};
		const rendered = renderer.create(<BarChart data={data} />);

		expect(rendered.toJSON()).toMatchSnapshot();	
	});

	test('It will return a horizontal bar chart', () => {
		const data = {
			params: {
				horizontalBars: true
			}
		};
		const result = mount(
			<BarChart data={data} />
		);
		const expected = 1;
		
		expect(result.find(`.${chartClasses.BAR_HORIZONTAL}`).length).toBe(expected);
	});

	test('It will return a stackbar chart up', () => {
		const data = {
			params: {
				stackBars: true,
				low: true,
				high: true
			},
			series: [
				[1]
			]
		};
		const result = mount(
			<BarChart data={data} />
		);
		const expected = 1;
		
		expect(result.find(`.${chartClasses.STACK_BAR_UP}`).length).toBe(expected);
	});

	test('It will return a stackbar chart down', () => {
		const data = {
			params: {
				stackBars: true,
				low: true,
				high: true
			},
			series: [
				[-1]
			]
		};
		const result = mount(
			<BarChart data={data} />
		);
		const expected = 1;
		
		expect(result.find(`.${chartClasses.STACK_BAR_DOWN}`).length).toBe(expected);
	});
});