import { call, put, takeEvery } from 'redux-saga/effects';

import watchFetchDetail, { fetchDetail } from './fetchDetail';
import actionTypes from '../actions/actionTypes';
import { modalSucceeded, modalGet, modalFailed } from '../actions/actionCreators';
import { fetchGet } from '../../api/async';
import { EQUITY_POSITIONS_DETAIL_DATA } from '../../constants';

describe('Test fetchDetail generator', () => {
	const comp = 'fooComp';
	const serviceName = 'fooService';
	const data = 'foo';
	const dataType = 'fooType';
	const gen = fetchDetail(modalGet(comp, serviceName));
	
    test('It will call fetchGet', () => {
        const result = gen.next().value;
		const expected = call(fetchGet, `${EQUITY_POSITIONS_DETAIL_DATA}${serviceName}`);
        
		expect(result).toEqual(expected);
    });
	
    test('It will put dataSucceeded action', () => {
        const result = gen.next(data).value;
		const expected = put(modalSucceeded(data, comp));

		expect(result).toEqual(expected);
    });
	
    test('It will be done on 3rd iteration', () => {
        const result = gen.next().done;
		const expected = true;
        
		expect(result).toBe(expected);
    });	
	
    test('It will put dataFailed action', () => {
		const gen = fetchDetail(modalGet(comp, serviceName));
		const err = { error: 'foo' };
		
		gen.next();
		
		const result = gen.throw(err).value;
		const expected = put(modalFailed(err));
		
		expect(result).toEqual(expected);
    });	
});	
	
describe('Test watchFetchDetail generator', () => {
	const gen = watchFetchDetail();
	
    test('It will call fetchDetail generator any number of times', () => {
        const result = gen.next().value;
		const expected = takeEvery(actionTypes.modal.GET, fetchDetail);

		expect(result).toEqual(expected);
    });

    test('It will be done on 2nd iteration', () => {
        const result = gen.next().done;
		const expected = true;

		expect(result).toBe(expected);
    });	
});