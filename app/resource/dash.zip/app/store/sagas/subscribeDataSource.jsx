import { call, put, takeEvery } from 'redux-saga/effects';

import actionTypes from '../actions/actionTypes';
import { dataReceived } from '../actions/actionCreators';
import { setSSE } from '../../api/async';
import { dataUrls } from '../../constants';


export function* watchMessages(action) {
	const msgSource = yield call(setSSE, action.url);
	let data = yield call(msgSource.nextMessage);

	while(data) {
		yield put(dataReceived(data, action.dataType, action.dataCol));
		data = yield call(msgSource.nextMessage);
	} 
}

export default function* subscribeDataSource() {
	yield takeEvery(actionTypes.data.SUBSCRIBE, watchMessages);
}