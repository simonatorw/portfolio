import { all } from 'redux-saga/effects';

import watchFetchData from './fetchData';
import subscribeDataSource from './subscribeDataSource';
import watchSaveTheme from './saveTheme';
import watchFetchDetail from './fetchDetail';

export default function* rootSaga() {
	yield all([
		watchFetchData(),
		subscribeDataSource(),
		watchSaveTheme(),
		watchFetchDetail()
	]);
}