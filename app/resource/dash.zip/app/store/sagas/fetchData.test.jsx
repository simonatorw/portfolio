import { call, put, takeEvery } from 'redux-saga/effects';

import watchFetchData, { fetchData } from './fetchData';
import actionTypes from '../actions/actionTypes';
import { dataSucceeded, dataGet, dataFailed } from '../actions/actionCreators';
import { fetchGet } from '../../api/async';

describe('Test fetchData generator', () => {
	const url = 'http://foo';
	const data = 'foo';
	const dataType = 'fooType';
	const gen = fetchData(dataGet(url, dataType));
	
    test('It will call fetchGet', () => {
        const result = gen.next().value;
		const expected = call(fetchGet, url);
        
		expect(result).toEqual(expected);
    });
	
    test('It will put dataSucceeded action', () => {
        const result = gen.next(data).value;
		const expected = put(dataSucceeded(data, dataType));

		expect(result).toEqual(expected);
    });
	
    test('It will be done on 3rd iteration', () => {
        const result = gen.next().done;
		const expected = true;
        
		expect(result).toBe(expected);
    });	
	
    test('It will put dataFailed action', () => {
		const gen = fetchData(dataGet(url, dataType));
		const err = { error: 'foo' };
		
		gen.next();
		
		const result = gen.throw(err).value;
		const expected = put(dataFailed(err));
		
		expect(result).toEqual(expected);
    });	
});	
	
describe('Test watchFetchData generator', () => {
	const gen = watchFetchData();
	
    test('It will call fetchData generator any number of times', () => {
        const result = gen.next().value;
		const expected = takeEvery(actionTypes.data.GET, fetchData);

		expect(result).toEqual(expected);
    });

    test('It will be done on 2nd iteration', () => {
        const result = gen.next().done;
		const expected = true;

		expect(result).toBe(expected);
    });	
});