import { call, put, takeEvery } from 'redux-saga/effects';

import subscribeDataSource, { watchMessages } from './subscribeDataSource';
import actionTypes from '../actions/actionTypes';
import { dataReceived, dataSubscribe } from '../actions/actionCreators';
import { setSSE } from '../../api/async';

describe('Test watchMessages generator', () => {
	const data = ['foo', 'bar'];
	const action = {
		url: ['foo', 'bar'],
		dataType: 'fooType',
		dataCol: 'fooCol'
	};
	const gen = watchMessages(dataSubscribe(action.url, action.dataType, action.dataCol));
	const msgSource = { nextMessage: jest.fn() };
	
    test('It will call setSSE', () => {
        const result = gen.next().value;
		const expected = call(setSSE, data);
        
		expect(result).toEqual(expected);
    });

    test('It will call msgSource.nextMessage', () => {
        const result = gen.next(msgSource).value;
		const expected = call(msgSource.nextMessage);
        
		expect(result).toEqual(expected);
    });	
	
    test('It will put dataReceived action', () => {
        const result = gen.next(data).value;
		const expected = put(dataReceived(data, action.dataType, action.dataCol));

		expect(result).toEqual(expected);
    });
	
    test('It will call msgSource.nextMessage again', () => {
        const result = gen.next(msgSource).value;
		const expected = call(msgSource.nextMessage);
		
		expect(result).toEqual(expected);
    });	
});	

describe('Test subscribeDataSource generator', () => {
	const gen = subscribeDataSource();
	
    test('It will call watchMessages generator any number of times', () => {
        const result = gen.next().value;
		const expected = takeEvery(actionTypes.data.SUBSCRIBE, watchMessages);

		expect(result).toEqual(expected);
    });

    test('It will be done on 2nd iteration', () => {
        const result = gen.next().done;
		const expected = true;

		expect(result).toBe(expected);
    });	
});