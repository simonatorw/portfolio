import { call, put, takeEvery } from 'redux-saga/effects';

import actionTypes from '../actions/actionTypes';
import { modalSucceeded, modalFailed } from '../actions/actionCreators';
import { fetchGet } from '../../api/async';
import { EQUITY_POSITIONS_DETAIL_DATA } from '../../constants';

export function* fetchDetail(action) {
	try {
		const data = yield call(fetchGet, `${EQUITY_POSITIONS_DETAIL_DATA}${action.serviceName}`);
		yield put(modalSucceeded(data, action.comp));
	} catch (err) {
		console.log(err);
		yield put(modalFailed(err));
	}
}

export default function* watchFetchDetail() {
	yield takeEvery(actionTypes.modal.GET, fetchDetail);
}