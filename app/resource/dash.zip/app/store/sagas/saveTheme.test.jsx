import { call, put, takeEvery } from 'redux-saga/effects';

import watchSaveTheme, { saveTheme } from './saveTheme';
import actionTypes from '../actions/actionTypes';
import { changeTheme, themeSaved } from '../actions/actionCreators';
import { saveThemeToStorage } from '../../api/utils';

describe('Test saveTheme generator', () => {
	const theme = 'foo';
	const gen = saveTheme(changeTheme(theme));
	
    test('It will call saveThemeToStorage', () => {
        const result = gen.next().value;
		const expected = call(saveThemeToStorage, theme);
        
		expect(result).toEqual(expected);
    });
	
    test('It will put themeSaved action', () => {
        const result = gen.next().value;
		const expected = put(themeSaved(theme));

		expect(result).toEqual(expected);
    });
	
    test('It will be done on 3rd iteration', () => {
        const result = gen.next().done;
		const expected = true;
        
		expect(result).toBe(expected);
    });	
});	
	
describe('Test watchSaveTheme generator', () => {
	const gen = watchSaveTheme();
	
    test('It will call saveTheme generator any number of times', () => {
        const result = gen.next().value;
		const expected = takeEvery(actionTypes.theme.CHANGE, saveTheme);

		expect(result).toEqual(expected);
    });

    test('It will be done on 2nd iteration', () => {
        const result = gen.next().done;
		const expected = true;

		expect(result).toBe(expected);
    });	
});