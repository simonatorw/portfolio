import * as actions from './actionCreators';
import actionTypes from './actionTypes';

describe('Test dataGet action creator', () => {
    test('It will generate an action to get restful data', () => {
        const url = 'http://foo';
		const dataType = 'myDataType';
		const expected = {
			type: actionTypes.data.GET,
			url,
			dataType
		};
		
        expect(actions.dataGet(url, dataType)).toEqual(expected);
    });		
});

describe('Test dataSucceeded action creator', () => {
    test('It will generate an action to receive restful data', () => {
        const data = { foo: 'bar' };
		const dataType = 'myDataType';
		const expected = {
			type: actionTypes.data.SUCCEEDED,
			data,
			dataType
		};
		
        expect(actions.dataSucceeded(data, dataType)).toEqual(expected);
    });	
});

describe('Test dataFailed action creator', () => {
    test('It will generate an action to notify error in getting restful data', () => {
        const err = 'myError';
		const expected = {
			type: actionTypes.data.FAILED,
			err
		};
		
        expect(actions.dataFailed(err)).toEqual(expected);
    });	
});

describe('Test dataSubscribe action creator', () => {
    test('It will generate an action to subscribe to sse data', () => {
        const url = 'http://foo';
		const dataType = 'myDataType';
		const dataCol = 'myDataCol';
		const expected = {
			type: actionTypes.data.SUBSCRIBE,
			url,
			dataType,
			dataCol
		};
		
        expect(actions.dataSubscribe(url, dataType, dataCol)).toEqual(expected);
    });
});

describe('Test dataReceived action creator', () => {
    test('It will generate an action to receive subscribed data', () => {
        const data = { foo: 'bar' };
		const dataType = 'myDataType';
		const dataCol = 'myDataCol';
		const expected = {
			type: actionTypes.data.RECEIVED,
			data,
			dataType,
			dataCol
		};
		
        expect(actions.dataReceived(data, dataType, dataCol)).toEqual(expected);
    });	
});

describe('Test changeTheme action creator', () => {
    test('It will generate an action to change the theme', () => {
		const theme = 'myTheme';
		const expected = {
			type: actionTypes.theme.CHANGE,
			theme
		};
		
        expect(actions.changeTheme(theme)).toEqual(expected);
    });	
});

describe('Test themeSaved action creator', () => {
    test('It will generate an action to confirm the theme is saved', () => {
		const theme = 'myTheme';
		const expected = {
			type: actionTypes.theme.SAVED,
			theme
		};
		
        expect(actions.themeSaved(theme)).toEqual(expected);
    });	
});

describe('Test modalGet action creator', () => {
    test('It will generate an action to get data for the modal', () => {
		const comp = 'myComp';
		const serviceName = 'myService';
		const expected = {
			type: actionTypes.modal.GET,
			comp,
			serviceName
		};
		
        expect(actions.modalGet(comp, serviceName)).toEqual(expected);
    });	
});

describe('Test modalSucceeded action creator', () => {
    test('It will generate an action to invoke modal with received data', () => {
		const data = { foo: 'bar' };
		const comp = 'myComp';
		const expected = {
			type: actionTypes.modal.SUCCEEDED,
			data,
			comp
		};
		
        expect(actions.modalSucceeded(data, comp)).toEqual(expected);
    });	
});

describe('Test modalFailed action creator', () => {
    test('It will generate an action to notify error in getting restful modal data', () => {
		const err = 'myError';
		const expected = {
		type: actionTypes.modal.FAILED,
			err
		};
		
        expect(actions.modalFailed(err)).toEqual(expected);
    });	
});

describe('Test modalClose action creator', () => {
    test('It will generate an action to close modal', () => {
		const expected = {
			type: actionTypes.modal.CLOSE
		};
		
        expect(actions.modalClose()).toEqual(expected);
    });	
});