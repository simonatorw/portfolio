import actionTypes from './actionTypes';

export const dataGet = (url, dataType) => ({
	type: actionTypes.data.GET,
	url,
	dataType
});

export const dataSucceeded = (data, dataType) => ({
	type: actionTypes.data.SUCCEEDED,
	data,
	dataType
});

export const dataFailed = (err) => ({
	type: actionTypes.data.FAILED,
	err
});

export const dataSubscribe = (url, dataType, dataCol) => ({
	type: actionTypes.data.SUBSCRIBE,
	url,
	dataType,
	dataCol
});

export const dataReceived = (data, dataType, dataCol) => ({
	type: actionTypes.data.RECEIVED,
	data,
	dataType,
	dataCol
});

export const changeTheme = theme => ({
	type: actionTypes.theme.CHANGE,
	theme
});

export const themeSaved = theme => ({
	type: actionTypes.theme.SAVED,
	theme
});

export const modalGet = (comp, serviceName) => ({
	type: actionTypes.modal.GET,
	comp,
	serviceName
});

export const modalSucceeded = (data, comp) => ({
	type: actionTypes.modal.SUCCEEDED,
	data,
	comp
});

export const modalFailed = err => ({
	type: actionTypes.modal.FAILED,
	err
});

export const modalClose = () => ({
	type: actionTypes.modal.CLOSE
});