import { retreiveTheme } from '../api/utils';

export default {
    keyMetrics: {
		headers: [],
		data: []
	},
    dailyPerformance: {
		headers: [],
		data: []
	},
    equityBeta: {
		headers: [],
		data: []
	},
    marketHeadlines: {
		headers: [],
		data: []
	},
	equityPositions: {
		headers: [],
		data: []
	},
	equityExposureBySector: {
		headers: [],
		data: []		
	},
    equityPositionsCount: {
		data: []
	},	
	equityPositionsNav: {
		data: []
	},
	theme: retreiveTheme(),
	modal: {
		title: '',
		comp: '',
		content: []
	}
};