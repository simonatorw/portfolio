import actionTypes from '../actions/actionTypes';
import stateTree from '../stateTree';
import { dataTypes } from '../../constants';

export default function dataReducer(state = stateTree, action) {

    switch(action.type) {
	    case actionTypes.data.SUCCEEDED:
			return { ...state, [action.dataType]: action.data };
	
		case actionTypes.data.RECEIVED:
			if (action.dataType === dataTypes.MARKET_HEADLINES) {
				const incomingData = state[action.dataType].data.slice();
				let newData;
				
				if (incomingData[0].headline.tick) {
					delete incomingData[0].headline.tick
				}
				if (incomingData[0].published.tick) {
					delete incomingData[0].published.tick
				}				
				incomingData.unshift(action.data);
				
				const currentDate = parseInt(incomingData[0].published.value.split(' ')[1], 10);
				
				if (currentDate !== parseInt(incomingData[incomingData.length - 1].published.value.split(' ')[1], 10)) {
					newData = incomingData.filter(item => currentDate === parseInt(item.published.value.split(' ')[1], 10));
				} else {
					newData = incomingData;
				}

				return { ...state, [action.dataType]: { headers: state[action.dataType].headers, data: newData }};
			} else {
				const newData = state[action.dataType].data.map((item, i) => {
					item[action.dataCol] = action.data[i];
					return item;
				});
			
				return { ...state, [action.dataType]: { headers: state[action.dataType].headers, data: newData }};
			}
			
        default:
            return state;
    }
}