import dataReducer from './dataReducer';
import actionTypes from '../actions/actionTypes';
import stateTree from '../stateTree';
import { dataTypes } from '../../constants';

describe('Test dataReducer', () => {
    test('It will return a default state', () => {
        const action = {};
        const result = dataReducer(undefined, action);
		const expected = stateTree;
        
		expect(result).toEqual(expected);
    });

    test('It will return unchanged state if there is no matched action', () => {
        const state = {};
        const action = {};
		const result = dataReducer(state, action);
		const expected = {};
        
		expect(result).toEqual(expected);
    });	
	
    test('It will receive restful data', () => {
        const state = {};
		const data = { foo: 'bar' };
		const dataType = 'fooBar';
        const action = {
			type: actionTypes.data.SUCCEEDED,
			data,
			dataType
		};
        const result = dataReducer(state, action);
		const expected = {
			[dataType]: data
		};
        
		expect(result).toEqual(expected);
    });

    test('It will receive sse data', () => {
        const state = {
			fooBar: {
				headers: [],
				data: [
					{ hello: 0, world: '' },
					{ hello: 1, world: '' }
				]
			}
		};
		const data = [3, 4];
		const dataType = 'fooBar';
		const dataCol = 'world';
        const action = {
			type: actionTypes.data.RECEIVED,
			data,
			dataType,
			dataCol
		};
        const result = dataReducer(state, action);
		const expected = {
			fooBar: {
				headers: [],
				data: [
					{ hello: 0, world: 3 },
					{ hello: 1, world: 4 }
				]
			}
		};
        
		expect(result).toEqual(expected);
    });

    test('It will receive news sse data and filter today\'s news if the date is new', () => {
        const state = {
			[dataTypes.MARKET_HEADLINES]: {
				headers: [],
				data: [
					{ headline: { tick: 'up' }, published: { value: 'Nov 3 12:30', tick: 'up' }},
					{ headline: {}, published: { value: 'Nov 2 12:30' }}
				]
			}
		};
		const data = { headline: { tick: 'up' }, published: { value: 'Nov 3 12:30', tick: 'up' }};
		const dataType = dataTypes.MARKET_HEADLINES;
		const dataCol = 'world';
        const action = {
			type: actionTypes.data.RECEIVED,
			data,
			dataType,
			dataCol
		};
        const result = dataReducer(state, action);
		const expected = {
			[dataTypes.MARKET_HEADLINES]: {
				headers: [],
				data: [
					{ headline: { tick: 'up' }, published: { value: 'Nov 3 12:30', tick: 'up' }},
					{ headline: {}, published: { value: 'Nov 3 12:30' }}
				]
			}
		};
        
		expect(result).toEqual(expected);
    });

    test('It will receive news sse data and add to today\'s news', () => {
        const state = {
			[dataTypes.MARKET_HEADLINES]: {
				headers: [],
				data: [
					{ headline: { tick: 'up' }, published: { value: 'Nov 2 12:30', tick: 'up' }},
					{ headline: {}, published: { value: 'Nov 2 12:30' }}
				]
			}
		};
		const data = { headline: { tick: 'up' }, published: { value: 'Nov 2 12:30', tick: 'up' }};
		const dataType = dataTypes.MARKET_HEADLINES;
		const dataCol = 'world';
        const action = {
			type: actionTypes.data.RECEIVED,
			data,
			dataType,
			dataCol
		};
        const result = dataReducer(state, action);
		const expected = {
			[dataTypes.MARKET_HEADLINES]: {
				headers: [],
				data: [
					{ headline: { tick: 'up' }, published: { value: 'Nov 2 12:30', tick: 'up' }},
					{ headline: {}, published: { value: 'Nov 2 12:30' }},
					{ headline: {}, published: { value: 'Nov 2 12:30' }}
				]
			}
		};
        
		expect(result).toEqual(expected);
    });

    test('It will receive news sse data and initially will not have to update indicator', () => {
        const state = {
			[dataTypes.MARKET_HEADLINES]: {
				headers: [],
				data: [
					{ headline: {}, published: { value: 'Nov 2 12:30' }},
					{ headline: {}, published: { value: 'Nov 2 12:30' }}
				]
			}
		};
		const data = { headline: { tick: 'up' }, published: { value: 'Nov 2 12:30', tick: 'up' }};
		const dataType = dataTypes.MARKET_HEADLINES;
		const dataCol = 'world';
        const action = {
			type: actionTypes.data.RECEIVED,
			data,
			dataType,
			dataCol
		};
        const result = dataReducer(state, action);
		const expected = {
			[dataTypes.MARKET_HEADLINES]: {
				headers: [],
				data: [
					{ headline: { tick: 'up' }, published: { value: 'Nov 2 12:30', tick: 'up' }},
					{ headline: {}, published: { value: 'Nov 2 12:30' }},
					{ headline: {}, published: { value: 'Nov 2 12:30' }}
				]
			}
		};
        
		expect(result).toEqual(expected);
    });	
});