import appReducer from './appReducer';
import actionTypes from '../actions/actionTypes';
import stateTree from '../stateTree';

describe('Test appReducer', () => {
    test('It will return a default state', () => {
        const action = {};
        const result = appReducer(undefined, action);
		const expected = stateTree;
        
		expect(result).toEqual(expected);
    });
	
    test('It will save a theme', () => {
        const state = {};
		const theme = 'myTheme';
        const action = {
			type: actionTypes.theme.SAVED,
			theme
		};
        const result = appReducer(state, action);
		const expected = {
			theme
		};
        
		expect(result).toEqual(expected);
    });
	
    test('It will open a modal', () => {
        const state = {};
		const data = { title: 'foo', panels: 'bar' };
		const comp = 'myComp'
        const action = {
			type: actionTypes.modal.SUCCEEDED,
			data,
			comp
		};
        const result = appReducer(state, action);
		const expected = {
			modal: {
				title: action.data.title,
				comp: action.comp,
				content: action.data.panels
			}
		};
        
		expect(result).toEqual(expected);
    });

    test('It will close a modal', () => {
        const state = {};
        const action = {
			type: actionTypes.modal.CLOSE
		};
        const result = appReducer(state, action);
		const expected = {
			modal: {
				title: undefined,
				comp: undefined,
				content: undefined
			}
		};
        
		expect(result).toEqual(expected);
    });

    test('It will return unchanged state if there is no matched action', () => {
        const state = {};
        const action = {};
		const result = appReducer(state, action);
		const expected = {};
        
		expect(result).toEqual(expected);
    });	
});