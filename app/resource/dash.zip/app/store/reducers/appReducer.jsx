import actionTypes from '../actions/actionTypes';
import stateTree from '../stateTree';

export default function appReducer(state = stateTree, action) {
    switch(action.type) {
		case actionTypes.theme.SAVED:
			return { ...state, theme: action.theme };

		case actionTypes.modal.SUCCEEDED:
		case actionTypes.modal.CLOSE:
			if (action.data) {
				return { ...state, modal: { title: action.data.title, comp: action.comp, content: action.data.panels }};
			} else {
				return { ...state, modal: { title: action.data }};
			}

        default:
            return state;
    }
}