export const SERVER = 'http://127.0.0.1:8124';

export const dataUrls = {
	KEY_METRICS_DATA: `${SERVER}/KeyMetrics`,
	DAILY_PERFORMANCE_DATA: `${SERVER}/DailyPerformance`,
	EQUITY_BETA_DATA: `${SERVER}/EquityBeta`,
	MARKET_HEADLINES_DATA: `${SERVER}/MarketHeadlines`,
	EQUITY_POSITIONS_DATA: `${SERVER}/EquityPositions`,
	EQUITY_EXPOSURE_BY_SECTOR_DATA: `${SERVER}/EquityExposureBySector`,
	EQUITY_POSITIONS_COUNT_DATA: `${SERVER}/EquityPositionsCount`,
	EQUITY_POSITIONS_NAV_DATA: `${SERVER}/EquityPositionsNav`
};

export const EQUITY_POSITIONS_DETAIL_DATA = `${SERVER}/EquityPositions/`;

export const subscribeUrls = {
	DAILY_PERFORMANCE_DATA_RT: `${SERVER}/DailyPerformanceRT`,
	EQUITY_POSITIONS_DATA_RT: `${SERVER}/EquityPositionsRT`,
	MARKET_HEADLINES_DATA_RT: `${SERVER}/MarketHeadlinesRT`
};

export const subscribeCols = {
	DAILY_PERFORMANCE_DATA_RT: 'vsPrevDay',
	EQUITY_POSITIONS_DATA_RT: 'dailyReturn'
};

export const dataTypes = {
	MARKET_HEADLINES: 'marketHeadlines'
};

export const chartTypes = {
	LINE: 'line',
	BAR: 'bar'
};

export const chartClasses = {
	BAR: 'barChart',
	STACK_BAR_UP:'stackBarChartUp',
	STACK_BAR_DOWN: 'stackBarChartDown',
	BAR_HORIZONTAL: 'barChartHorizontal'
};

export const theming = {
	STORAGE_KEY: 'dashboard_theme'
};

export const nativeTypes = {
	STRING: 'string',
	NUMBER: 'number',
	OBJECT: 'object'
};

export const gridClasses = {
	LINK: 'link',
	EMPTY: 'empty',
	CHART: 'chart',
	AMT: 'amt',
	NEG_AMT: 'negAmt',
	UP: 'tickerUp',
	UP0: 'tickerUp0',
	DOWN: 'tickerDown',
	DOWN0: 'tickerDown0'
};

export const ticker = {
	UP: 'up',
	DOWN: 'down'
};
