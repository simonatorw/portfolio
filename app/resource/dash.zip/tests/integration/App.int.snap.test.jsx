import React from 'react';
import { configure, mount } from 'enzyme';
import toJson from 'enzyme-to-json';
import Adapter from 'enzyme-adapter-react-15';
import { Provider } from 'react-redux';

jest.mock('../../app/api/date');
import { getTodaysDate } from '../../app/api/date';
import App from '../../app/components/App';
import store from '../../app/store/store';
import { modalGet } from '../../app/store/actions/actionCreators';

configure({ adapter: new Adapter() });

function flushAllPromises() {
	return new Promise(resolve => setImmediate(resolve));
}

getTodaysDate.mockReturnValue('December 21, 2017');

describe('Test entire App', () => {
	let rendered;
	
	beforeAll(async () => {
		rendered = mount(
			<Provider store={store}>
				<App />
			</Provider>
		);
		
		await flushAllPromises();
		rendered.update();
		await flushAllPromises();
		rendered.update();		
	});

	test('It will match the entire App snapshot', () => {				
		expect(toJson(rendered)).toMatchSnapshot();	
    });
	
	test('It will have 6 grids', () => {		
		const tables = rendered.find('.dataGrid');
		const result = tables.length;
		const expected = 6;
		
		expect(result).toBe(expected);	
    });

	test('It will have 2 chart panels', () => {		
		const panels = rendered.find('.chartSmall');
		const result = panels.length;
		const expected = 2;
		
		expect(result).toBe(expected);	
    });
	
	describe('Test modal integration', () => {
		test('It will have not show a modal initially', () => {		
			const modal = rendered.find('.modal');
			const result = modal.length;
			const expected = 0;
			
			expect(result).toBe(expected);	
		});

		test('It will have show a modal after clicking a link', async () => {				
			const eqPosGrid = rendered.find('.dataGrid').last();
			const secLink = eqPosGrid.find('.link').at(1);
			
			secLink.simulate('click');
			
			await flushAllPromises();
			rendered.update();
			
			const modal = rendered.find('.modal');
			const result = modal.length;
			const expected = 1;
			
			expect(result).toBe(expected);
		});

		test('It will close the modal after clicking away', async () => {				
			const screen = rendered.find('.screen');
			
			screen.simulate('click');
			
			await flushAllPromises();
			rendered.update();		
			
			const modal = rendered.find('.modal');
			const result = modal.length;
			const expected = 0;
			
			expect(result).toBe(expected);
		});

		test('It will close the modal after clicking the close icon', async () => {
			const eqPosGrid = rendered.find('.dataGrid').last();
			const secLink = eqPosGrid.find('.link').at(1);
			
			secLink.simulate('click');
			
			await flushAllPromises();
			rendered.update();
		
			const closeIcon = rendered.find('.closeIcon');
			
			closeIcon.simulate('click');
			
			await flushAllPromises();
			rendered.update();		
			
			const modal = rendered.find('.modal');
			const result = modal.length;
			const expected = 0;
			
			expect(result).toBe(expected);
		});
	});
	
	describe('Test real-time data for Daily Performance', () => {
		let dpPanel;
		
		beforeAll(() => {
			dpPanel = rendered.find('.panel').at(2);
		});
		
		test('It will display DP real-time data with uptick style class', () => {
			const gridCell = dpPanel.find('.tickerUp0');
			const result = gridCell.text();
			const expected = '$51M';
			
			expect(result).toBe(expected);
		});

		test('It will display DP real-time data with downtick style class', () => {
			const gridCell = dpPanel.find('.tickerDown0');
			const result = gridCell.text();
			const expected = '-3.6%';
			
			expect(result).toBe(expected);
		});

		test('It will display DP real-time data with no style class', () => {
			const gridRow = dpPanel.find('.gridRow').at(2);
			const gridCell = gridRow.find('.gridCell').at(2);
			const result = gridCell.is('.gridCell.negAmt');
			const expected = true;
			
			expect(result).toBe(expected);
		});
	});

	describe('Test real-time data for Market Headlines', () => {
		test('It will display MH real-time data with uptick style class', () => {
			const mhPanel = rendered.find('.panel').at(4);
			const gridCell = mhPanel.find('.tickerUp0');
			const result = gridCell.length;
			const expected = 2;
			
			expect(result).toBe(expected);
		});
	});

	describe('Test real-time data for Equity Positions', () => {
		let eqPanel;
		
		beforeAll(() => {
			eqPanel = rendered.find('.panel').at(8);
		});
		
		test('It will display EP real-time data with uptick style class', () => {
			const gridCell = eqPanel.find('.tickerUp0');
			const result = gridCell.text();
			const expected = '3%';
			
			expect(result).toBe(expected);
		});

		test('It will display EP real-time data with downtick style class', () => {
			const gridCell = eqPanel.find('.tickerDown0');
			const result = gridCell.text();
			const expected = '3%';
			
			expect(result).toBe(expected);
		});

		test('It will display EP real-time data with no style class', () => {
			const gridRow = eqPanel.find('.gridRow').at(2);
			const gridCell = gridRow.find('.gridCell').at(3);
			const result = gridCell.is('.gridCell.negAmt');
			const expected = true;
			
			expect(result).toBe(expected);
		});
	});	
});