import { Selector } from 'testcafe';
import { getTodaysDate } from '../../app/api/date.jsx';

fixture `Test dashboard e2e`
	.page `http://localhost:8080/`;

test('It should have the correct title', async t => {
	const title = Selector('h1').innerText;
	const expected = `Daily Metrics | Portfolio Manager - Equity | ${getTodaysDate()}`;
	
	await t
		.expect(title).eql(expected)
});

test('It should have 9 panels', async t => {
	const panels = Selector('.panel');
	const expected = 9;
	
	await t
		.expect(panels.count).eql(expected);
});

test('It can select a theme', async t => {
	const dropdown = Selector('select');
	const options = Selector('select').find('option');
	let expected = 1;
	
	await t
		.click(dropdown)
		.click(options.nth(1))
		.expect(dropdown.selectedIndex).eql(expected)
		.wait(600);
		
	expected = 0;
	
	await t
		.click(dropdown)
		.click(options.nth(0))
		.expect(dropdown.selectedIndex).eql(expected)
		.wait(1000);
});

test('It can open and close a modal', async t => {
	const modal = Selector('.modal');
	const modalLink1 = Selector('.long').find('.link').nth(0);
	const subTitle = Selector('.modal h2').innerText;
	const modalLink2 = Selector('.long').find('.link').nth(1);
	const closeIcon = Selector('.closeIcon');
	const screen = Selector('.screen');
	const expectedSubTitle1 = 'Baxter International Inc';
	const expectedSubTitle2 = 'Nestle SA';
	let expected = 1;
	
	await t
		.click(modalLink1)
		.expect(modal.count).eql(expected)
		.expect(subTitle).eql(expectedSubTitle1)
		.wait(600);
		
	expected = 0;
	
	await t
		.click(closeIcon)
		.expect(modal.count).eql(expected)
		.wait(600)
		.click(modalLink2)
		.expect(subTitle).eql(expectedSubTitle2)
		.wait(600)
		.click(screen, { offsetX: 10, offsetY: 10 })
		.expect(modal.count).eql(expected)
		.wait(1000);
});

test('It is getting real-time data', async t => {
	let panel = Selector('.panel').nth(2);
	let subTitle = panel.find('h2').innerText;
	let rtData = panel.find('.amt').nth(0).innerText;
	let expectedSubTitle = 'Daily Performance';
	let expectedData = 'M';
	
	await t
		.expect(subTitle).eql(expectedSubTitle)
		.expect(rtData).contains(expectedData);
		
	panel = Selector('.panel').nth(8);
	subTitle = panel.find('h2').innerText;
	rtData = panel.find('.gridCell').nth(3).innerText;
	expectedSubTitle = 'Equity Positions';
	expectedData = '%';
	
	await t
		.expect(subTitle).eql(expectedSubTitle)
		.expect(rtData).contains(expectedData);		
});

test('It is getting grid data', async t => {
	const expected = 0;
	
	for (let i = 0; i < 6; i++) {
		await t.expect(Selector('.dataGrid').nth(i).find('.gridRow').count).gt(expected);
	}
});

test('It is getting large charts', async t => {
	const chart1 = Selector('.panel').nth(6).find('.lineChart').count;
	const chart2 = Selector('.panel').nth(7).find('.lineChart').count;
	const expected = 1;
	
	await t
		.expect(chart1).eql(expected)
		.expect(chart2).eql(expected);
});