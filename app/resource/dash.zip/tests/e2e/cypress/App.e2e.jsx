import { getTodaysDate } from '../../../app/api/date.jsx';

describe('Test dashboard e2e', function () {
	before(function() {
		cy.visit('/');
	});
	
	it('Should have the correct title', function() {	
		cy.contains(`Daily Metrics | Portfolio Manager - Equity | ${getTodaysDate()}`);
	});
	
	it('ShouId have 9 panels', function() {	
		cy.get('.panel')
			.should('have.length', 9);
	});

	it('Can select a theme', function() {	
		cy.get('.themeSelect')
			.select('Bloomie')
			.should('have.value', 'Bloomie')
			.wait(600)
			.select('Simple')
			.should('have.value', 'Simple');						
	});

	it('Can open and close a modal', function() {	
		cy.get('.long .link')
			.eq(0)
			.click();
			
		cy.get('.modal')
			.should('have.length', 1)
			.wait(600);
			
		cy.get('.closeIcon')
			.click();
			
		cy.get('.modal')
			.should('have.length', 0);
			
		cy.get('.long .link')
			.eq(1)
			.click()
			.wait(600);
					
		cy.get('.screen')
			.click('topRight', { force: true });
			
		cy.get('.modal')
			.should('have.length', 0);			

	});

	it.skip('Gets real-time data', function() {	
		cy.get('.panel')
			.eq(2)
			.find('h2')
			.contains('Daily Performance');
			
		cy.get('.panel')
			.eq(2)
			.find('.amt')
			.contains('M');			
	});
	
	it('Gets grid data', function() {
		for (let i = 0; i < 6; i++) {
			cy.get('.dataGrid')
				.eq(i)
				.find('.gridRow')
				.should(row => {
					expect(row.length).to.be.above(0);
				});
		}
	});

	it('Gets large chart data', function() {
		for (let i = 6; i < 8; i++) {
			cy.get('.panel')
				.eq(i)
				.find('.lineChart')
				.should(row => {
					expect(row.length).to.equal(1);
				});
		}
	});	
});

/*

test('It is getting real-time data', async t => {
	let panel = Selector('.panel').nth(2);
	let subTitle = panel.find('h2').innerText;
	let rtData = panel.find('.amt').nth(0).innerText;
	let expectedSubTitle = 'Daily Performance';
	let expectedData = 'M';
	
	await t
		.expect(subTitle).eql(expectedSubTitle)
		.expect(rtData).contains(expectedData);
		
	panel = Selector('.panel').nth(8);
	subTitle = panel.find('h2').innerText;
	rtData = panel.find('.gridCell').nth(3).innerText;
	expectedSubTitle = 'Equity Positions';
	expectedData = '%';
	
	await t
		.expect(subTitle).eql(expectedSubTitle)
		.expect(rtData).contains(expectedData);		
});

*/