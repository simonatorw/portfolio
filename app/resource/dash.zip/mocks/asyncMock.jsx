import 'babel-polyfill';
import KeyMetrics from '../app/resource/KeyMetricsData';
import DailyPerformance from '../app/resource/DailyPerformanceData';
import EquityBeta from '../app/resource/EquityBetaData';
import MarketHeadlines from '../app/resource/MarketHeadlinesData';
import EquityPositions from '../app/resource/EquityPositionsData';
import EquityExposureBySector from '../app/resource/EquityExposureBySectorData';
import EquityPositionsCount from '../app/resource/EquityPositionsCountData';
import EquityPositionsNav from '../app/resource/EquityPositionsNavData';
import NestleSA from '../app/resource/EquityPositions/NestleSAData';

const mod = {
	KeyMetrics,
	DailyPerformance,
	EquityBeta,
	MarketHeadlines,
	EquityPositions,
	EquityExposureBySector,
	EquityPositionsCount,
	EquityPositionsNav,
	NestleSA
};

function getJsonFile(url) {
	const key = url.split('/');
	
	return mod[key[key.length - 1]];
}

function getRTData(url) {
	const key = url.split('/');
	const dataType = key[key.length - 1];	
	
	switch(dataType) {
		case 'DailyPerformanceRT':
			return [
				'[{ "value": "$51M", "tick": "up" },{ "value": "-3.6%", "tick": "down" },{ "value": "-3.63%", "tick": "none" },{ "value": "3.05%", "tick": "none" },{ "value": "2.18%", "tick": "none" }]'
			];
		case 'EquityPositionsRT':
			return [			
				'[{ "value": "3%", "tick": "up" },{ "value": "3%", "tick": "down" },{ "value": "-2.7%", "tick": "none" },{ "value": "2.8%", "tick": "none" },{ "value": "3%", "tick": "none" },{ "value": "2.8%", "tick": "none" },{ "value": "-2.8%", "tick": "none" },{ "value": "1.3%", "tick": "none" },{ "value": "2.6%", "tick": "none" },{ "value": "-2.4%", "tick": "none" }]'
			];
		case 'MarketHeadlinesRT':
			return [				
				'{ "headline": { "text": "Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa.", "url": "https://www.yahoo.com/news/", "tick": "up" }, "published": { "value": "Jan 10 11:5", "tick": "up" }}'
			];
		default:
			return [];
	}
}

const fetchMock = responseObj => {
	let deferred = {};

	deferred.promise = new Promise(resolve => deferred.resolve = resolve); 
	deferred.resolve({
		json: function() { 
			return (typeof responseObj === 'string' && responseObj.includes('http://')) ? getJsonFile(responseObj) : responseObj;
		}
	});

	return deferred.promise;
};

Object.defineProperty(window, 'fetch', { value: fetchMock });

function EventSourceMock(dataValue) {
	let listener;
	let count = 0;
	let mockParam = false;

	if (!Array.isArray(dataValue) && dataValue.includes('http://')) {
		dataValue = getRTData(dataValue);
	} else {
		mockParam = true;
	}
	
	
	const msg = setInterval(() => {
		if (count < dataValue.length) {
			listener(mockParam ? { data: `"${dataValue[count]}"` } : { data: dataValue[count] })
		} else {
			clearInterval(msg)
			listener({ data: null })
		}
		count++;
	}, 0);

	return {
		set onmessage(l) {
			listener = l;
		}			
	};		
}

Object.defineProperty(window, 'EventSource', { value: EventSourceMock });