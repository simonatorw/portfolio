module.exports = {
	plugins: {
		'postcss-import': {},
		'precss': {},
		'postcss-cssnext': {}
	}
}